


public class NumeroNegativo extends ArithmeticException {

    public NumeroNegativo() {
    }

    public NumeroNegativo(String message) {
        super(message);
    }
}
